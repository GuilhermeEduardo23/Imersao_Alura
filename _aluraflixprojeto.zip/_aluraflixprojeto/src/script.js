const filmes = Array('https://br.web.img3.acsta.net/medias/nmedia/18/91/90/98/20169244.jpg', 'https://media.fstatic.com/DjhdaLmpvfJaleMFTvM2aN1-zq8=/322x478/smart/filters:format(webp)/media/movies/covers/2016/08/chegada_2-1.jpg', 'https://www.sonypictures.com.br/sites/brazil/files/2023-06/1400x2100.jpg');

filmes.push('https://musicart.xboxlive.com/7/bfe22100-0000-0000-0000-000000000002/504/image.jpg?', 'https://cdn.pumpkin.pt/wp-content/uploads/2017/06/POSTER_CARROS3.jpg');

for(let i = 0; i < filmes.length; i++) {
  document.write('<img src=' + filmes[i] + '>');
}