/* Conversor Interestelar */

let nome = prompt("Olá viajante do espaço! Por favor, me diga qual seu nome?");

let valorAnosLuz = prompt(
  `${nome}, quantos anos luz você deseja saber em metros?`
);

const metro = 9460528405000020;

let anosLuzEmMetros = metro * valorAnosLuz;

alert(`${nome}, o valor ${valorAnosLuz} em metros é: ${anosLuzEmMetros}`);
