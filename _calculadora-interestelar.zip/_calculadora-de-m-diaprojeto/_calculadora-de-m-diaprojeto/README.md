# _Calculadora de média - Projeto

A Pen created on CodePen.io. Original URL: [https://codepen.io/GuilhermeEdu/pen/vYbJOEL](https://codepen.io/GuilhermeEdu/pen/vYbJOEL).

