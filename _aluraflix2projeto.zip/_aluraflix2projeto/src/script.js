function adicionarFilme() {
  const nomeFilme = document.getElementById('filme').value;
  const divFilmes = document.getElementById('listaFilmes');
  const img = document.createElement('img');
  
  if(nomeFilme.endsWith('.jpg') || nomeFilme.endsWith('.png')) {
    alert('O link do filme está correto. Adicionando na lista!');
  } else {
    alert('O link do filme não está correto!');
  }
  
  img.setAttribute('src', nomeFilme);
  
  divFilmes.appendChild(img);
  
  document.getElementById('filme').value = '';
}