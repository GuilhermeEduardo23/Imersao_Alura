var numeroSecreto = parseInt(Math.random() * 1001);
var chute;
var numeroDeChutes = 10;

while(chute != numeroSecreto) {
  chute = prompt('Digite um número entre 0 e 1000');
  
    if(chute == numeroSecreto) {
      alert(`Você acertou o número secreto!!!\nVocê acertou na ${numero}º tentativa.`);
    } else if(chute < numeroSecreto) {
      numeroDeChutes--;
      alert(`${chute} é menor que o número secreto!\nTente outra vez.`);
    } else {
      numeroDeChutes--;
      alert(`${chute} é maior que o número secreto!\nTente outra vez.`);
    }
  
    if(numeroDeChutes != 0) {
      alert(`Você tem ${numeroDeChutes} tentativas.`);
    } else {
      alert(`Suas tentativas acabaram. Fim de jogo! O número secreto é ${numeroSecreto}.`);
      break;
    }
}